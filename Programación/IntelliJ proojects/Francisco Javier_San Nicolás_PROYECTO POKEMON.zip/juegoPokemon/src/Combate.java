public class Combate {

    // Añada los atributos y el constructor *************

    private Pokemon pokemonJugador;
    private Pokemon pokemonRival;

    public Combate (Pokemon jugador, Pokemon rival){
        this.pokemonJugador = jugador;
        this.pokemonRival = rival;
    }

    //***************************************************


    public Pokemon Ronda(){
        int poderJugador = this.pokemonJugador.calcularPoder(pokemonJugador);
        int poderRival = this.pokemonRival.calcularPoder(pokemonRival); //Guardamos los poderes de los pokemon jugador y rival llamando al metodo calcularPoder(Pokemon) en variables locales
         if (poderJugador > poderRival){ //Poder jugador es mayor que el poder rival, gana el jugador.
             this.pokemonRival.disminuirAguante(); //Disminuye el aguante del perdedor
             return this.pokemonJugador; //Devuelve al pokemon ganador de la ronda
         }else if (poderRival > poderJugador){ //Poder rival es mayor que el poder jugador, gana el rival
             this.pokemonJugador.disminuirAguante(); //Disminuye el aguante del perdedor
             return this.pokemonRival;//Devuelve al pokemon ganador de la ronda
         }else{
             return null;
         }

    }

    public Pokemon Ganador(){ //Devuelve el pokemon que ha ganado LA PARTIDA, es decir, el que aún tiene aguante cuando el otro ya no.
        if (this.pokemonJugador.getAguante() == 0){

            return this.pokemonRival;
        } else if (this.pokemonRival.getAguante() == 0){

            return this.pokemonJugador;
        }else {
            return null; //Si nadie gana devuelve un null.
        }
    }


}
