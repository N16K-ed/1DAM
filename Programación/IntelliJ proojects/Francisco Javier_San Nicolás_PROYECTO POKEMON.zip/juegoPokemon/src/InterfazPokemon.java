import java.util.Scanner;
public class InterfazPokemon {
    private Scanner teclado;

    public InterfazPokemon(){
        teclado = new Scanner(System.in);
    }

    public void Juego() {
        Pokemon jugador = menuCreacionPokemonJugador(); //Guarda al pokemon del jugador en una variable local
        Pokemon rival = siguientePokemonRival(1); //Guarda al pokemon del rival en otra variable local
        System.out.println("\nPULSE ENTER PARA CONTINUAR");
        teclado.nextLine();
        teclado.nextLine(); // Solución a la que he llegado para que el PULSE ENTER funcione
        Partida(jugador, rival); //Partida 1 con los dos pokemon.
        if (Partida(jugador, rival) == rival){ // Si gana el rival:
            System.out.println(rival.getNombre() + " te ha derrotado.");
            mostrarFinPartida();
        }else{ // Si no gana el rival, es decir, gana el jugador.
            System.out.println("Genial: Has derrotado a " + rival.getNombre());
            jugador.subirNivel();
            System.out.println("\nPULSE ENTER PARA CONTINUAR");
            teclado.nextLine();
            rival = siguientePokemonRival(2); // Se presenta el pokemon rival al cambiarlo.
            System.out.println("\nPULSE ENTER PARA CONTINUAR");
            teclado.nextLine();
            Partida(jugador, rival); // como rival se ha actualizado, ahora la partida es con un nuevo rival
            if (Partida(jugador,rival) == rival){
                System.out.println(rival.getNombre() + " te ha derrotado.");
                mostrarFinPartida();
            } else{
                System.out.println("Genial: Has derrotado a " + rival.getNombre());
                jugador.subirNivel();
                System.out.println("\nPULSE ENTER PARA CONTINUAR");
                teclado.nextLine();
                rival = siguientePokemonRival(3);
                System.out.println("\nPULSE ENTER PARA CONTINUAR");
                teclado.nextLine();
                Partida(jugador,rival);
                if (Partida(jugador,rival) == jugador){
                    System.out.println("Genial: Has derrotado a " + rival.getNombre());
                    System.out.println("\nPULSE ENTER PARA CONTINUAR");
                    teclado.nextLine();
                    mostrarJuegoSuperado();
                }else{
                    System.out.println(rival.getNombre() + " te ha derrotado.");
                    mostrarFinPartida();
                }
            }
        }

    }

    private Pokemon Partida(Pokemon pokemonJugador, Pokemon pokemonRival){
        Combate combate = new Combate(pokemonJugador, pokemonRival); //Se crea un combate con los pokemon jugador y rival
        while (pokemonJugador.getAguante() > 0 && pokemonRival.getAguante() > 0){
            Pokemon ganaRonda = combate.Ronda(); //Llama al metodo Ronda() que devuelve el pokemon que gana la ronda y disminuye el aguante del pokemon que pierde
            if (ganaRonda == null){  //empate
                System.out.println("empate en esta ronda");
                System.out.println("Aguante de " + pokemonJugador.getNombre() + ": " + pokemonJugador.getAguante());
                System.out.println("Aguante de " + pokemonRival.getNombre() + ": " + pokemonRival.getAguante());
            }else{ //alguien gana
                System.out.println("Gana la ronda: " + ganaRonda.getNombre());
                System.out.println("Aguante de " + pokemonJugador.getNombre() + ": " + pokemonJugador.getAguante());
                System.out.println("Aguante de " + pokemonRival.getNombre() + ": " + pokemonRival.getAguante());
            }

        }
        return combate.Ganador();
    }


    private Pokemon menuCreacionPokemonJugador(){
        System.out.println("..........................................................");
        System.out.println("Crea tu pokemon ......");
        System.out.println("..........................................................");
        System.out.println("Introduce un nombre:");
        String nombre = teclado.next();
        System.out.println("Elige su tipo:");
        System.out.println("1.- Agua");
        System.out.println("2.- Tierra");
        System.out.println("3.- Fuego");
        int tipo = teclado.nextInt(); //Se pide un int como en el ejemplo de consola
        String tipoS; //Sin inicializar, para convertir el int del tipo en un string que es como se guarda el tipo en la clase Pokemon.
        while (tipo != 1 && tipo != 2 && tipo != 3){ //hacemos que si o si el int que guarda el tipo sea 1, 2 o 3.
            System.out.println("Introduzca un tipo válido");
            tipo = teclado.nextInt();
        }
        if(tipo == 1){
            tipoS = "Agua";
        }else if (tipo == 2){
            tipoS = "Tierra";
        }else{
            tipoS = "Fuego";
        }
        return new Pokemon(nombre, tipoS); //devuelve el pokemon creado
    }

    public Pokemon siguientePokemonRival(int numero) {
    if (numero == 1){
        Pokemon rival = new Pokemon("Caterpie","Tierra",1 );
        System.out.println("Presentación del pokemon oponente:");
        System.out.println(rival);
        return rival;
    }else if (numero == 2){
        Pokemon rival = new Pokemon("Bulbasaur","Agua",2 );
        System.out.println("Presentación del pokemon oponente:");
        System.out.println(rival);
        return rival;
    }else {
        Pokemon rival = new Pokemon("Charmander","Fuego",3 );
        System.out.println("Presentación del pokemon oponente:");
        System.out.println(rival);
        return rival;
    }

    }

    private void mostrarJuegoSuperado(){
        System.out.println("++++++++++ ENHORABUENA +++++++++++");
        System.out.println("+++++ HAS SUPERADO EL JUEGO ++++++");
        System.out.println("++++ ERES UN MAESTRO POKEMON +++++");
    }

    private void mostrarFinPartida(){
        System.out.println("++++++++++ LO SIENTO +++++++++++");
        System.out.println("+++++ HAS SIDO ELIMINADO ++++++");
        System.out.println("+++++ VUELVE A INTENTARLO +++++");
    }

}
