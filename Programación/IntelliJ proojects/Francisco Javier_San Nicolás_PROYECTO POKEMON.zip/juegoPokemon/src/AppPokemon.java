public class AppPokemon {

    public static void main(String[] args) {
        InterfazPokemon juegoPokemon = new InterfazPokemon();
        juegoPokemon.Juego();

    }

}
